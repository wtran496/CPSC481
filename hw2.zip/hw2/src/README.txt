This program is to ask the user to input 5 numbers (the NumberPublisher file) and output the sum of the unique numbers (NumberListener).
The steps to create the .out file is listed below:


Creating the .o files:
g++ -c -m64 -Wall -l Main.lis -o Main.o Main.cpp
g++ -c -m64 -Wall -l NumberPublisher.lis -o NumberPublisher.o NumberPublisher.cpp
g++ -c -m64 -Wall -l NumberListener.lis -o NumberListener.o NumberListener.cpp

Link:
g++ -m64 -o main.out NumberListener.o NumberPublisher.o Main.o

Execute:
./main.out
