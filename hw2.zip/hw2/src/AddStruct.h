struct sum{
	int add;
	bool unique;
	sum *next;

};
