#include <iostream>

int main(){

std::cout << "Hello, World! This is my first robot program.\n";
return 0;
}
