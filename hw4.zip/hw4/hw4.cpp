#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>
#include <turtlesim/Spawn.h>
#include <turtlesim/Kill.h>
#include <string>
using namespace std;
ros::Publisher velocity_publisher;
ros::Subscriber pose_subscriber;
turtlesim::Pose turtlesim_pose;
const double PI = 3.14159265359;

void poseCallback(const turtlesim::Pose::ConstPtr &pose_message){
	turtlesim_pose.x = pose_message -> x;
	turtlesim_pose.y = pose_message -> y;
	turtlesim_pose.theta = pose_message -> theta;
}
double getDistance(double x1, double y1, double x2, double y2){
return sqrt(pow((x1-x2),2) + pow((y1-y2),2));
}
//		turtle1			turtle2
void moveGoal (double x, double y, double x1, double y1) {
	geometry_msgs::Twist vel_msg;
	ros::Rate loop_rate(100);
	double E = 0.0;
	double t1 = x;
	double t2 = y;
	do {
	//Proportional Controller
	//linear velocity in the x-axis
	double Kv = 1;
	//double Ki = 0.02;
	//double v0 = 2.0;
	//double alpha = 0.5;

	//getDistance calculates Euclidean distance
	double e = getDistance(turtlesim_pose.x, turtlesim_pose.y, t1, t2);
	
	//double E = E + e;
	//Kv = v0 * (exp(-alpha)*error*error)/(error*error); //try something else
	vel_msg.linear.x = (Kv*e);
	vel_msg.linear.y = 0;
	vel_msg.linear.z = 0;
	//angular velocity in the z-axis
	vel_msg.angular.x = 0;
	vel_msg.angular.y = 0;

	
	//Kw value must be adjusted carefully a little by little, trying theta* = theta
	//Large Kw value may cause strange behavior due to too big change of the turtle’s orientation.
	double Kw = 1.1;

	//---need to figure out the angle for this to go around Xturtles
	vel_msg.angular.z = Kw*(atan2(t2 - turtlesim_pose.y, t1 - turtlesim_pose.x) - turtlesim_pose.theta); // Kw(θ * - θ)
	//angular.z is the relative angle to rotate calculated by (absolute_angle – turtle’s orientation)

	//---to prevent offbounds (0,0) (11,11)
	if (turtlesim_pose.y >= 0 || turtlesim_pose.x >= 0 || turtlesim_pose.y <= 11 || turtlesim_pose.x <= 11)
		velocity_publisher.publish(vel_msg);
	else
		break;
	//---CURRENTLY TRYING TO THINK OF CONDITIONS TO MAKE OUR TURTLE WALK AROUND XTURTLES

	//---go to turtle2 when our turtle is at turtle1
	/*if (getDistance(turtlesim_pose.x, turtlesim_pose.y, x, y) <= 0.5){
		t1 = x1;
		t2 = y1;
	}*/
	ROS_INFO("X: %f , Y: %f", turtlesim_pose.x, turtlesim_pose.y);
	ros::spinOnce();
	loop_rate.sleep();
	
	//----finish when our turtle is at turtle2
	} while(getDistance(turtlesim_pose.x, turtlesim_pose.y, x, y) >= 0.5);
	std::cout<<"end move goal"<<std::endl;

	vel_msg.linear.x = 0;
	vel_msg.angular.z = 0;
	velocity_publisher.publish(vel_msg);
}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "hw4a");
  ros::NodeHandle n;
  turtlesim::Pose msg;
	double pair = 0; //to check the furthest pair
	turtlesim::Pose msg1;
	stringstream jname; 
	double distance = 0; //check pair distances
  stringstream tname;
  ros::Rate loop_rate(2);
  int turtle1 = 1; //store Tturtle1
  int turtle2 = 1; //store Tturtle2
  int turts = 5;
  ros::Subscriber Tturts;
	for(int i = 0; i < turts-1; i ++ ){
		tname.clear();
		tname.str("");
		tname << "/T" << i+1 << "/pose";
		string name = tname.str();
		
		try{msg = *(ros::topic::waitForMessage<turtlesim::Pose>(name, ros::Duration(2)));}
		catch (int e){ROS_INFO("COULDNT FIND THAT TURT");}
		ROS_INFO("X: %f,  Y: %f", msg.x, msg.y);
		//i+1 to compare each turtle
		for (int j = i+1; j < turts; j++){
			jname.clear();
			jname.str("");
			jname << "/T" << j+1 << "/pose";
			string name = jname.str();

			try{msg1 = *(ros::topic::waitForMessage<turtlesim::Pose>(name, ros::Duration(2)));}
			catch (int e){ROS_INFO("COULDNT FIND THAT TURT");}
			ROS_INFO("X1: %f,  Y1: %f", msg1.x, msg1.y);
			//get the distance
			double distance = getDistance(msg.x,msg.y,msg1.x,msg1.y);
			//check the distance
			ROS_INFO("Distance: %f",distance);
			if (distance > pair){
				//Check the pair
				ROS_INFO("PAIR AND DISTANCE: %f , %f",pair,distance);
				turtle1 = i+1;
				turtle2 = j+1;
				pair = distance;
			}
		ros::spinOnce();
		loop_rate.sleep();
		}
	ros::spinOnce();
	loop_rate.sleep();
	}
	
	//This whole section display the pairs
	tname.clear();
	tname.str("");
	tname << "/T" << turtle1 << "/pose";
	string name = tname.str();
	try{msg = *(ros::topic::waitForMessage<turtlesim::Pose>(name, ros::Duration(2)));}
	catch (int e){ROS_INFO("COULDNT FIND THAT TURT");}
	name.clear();
		
	jname.str("");
	jname << "/T" << turtle2 << "/pose";		
	name = jname.str();
	try{msg1 = *(ros::topic::waitForMessage<turtlesim::Pose>(name, ros::Duration(2)));}
	catch (int e){ROS_INFO("COULDNT FIND THAT TURT");}
	name.clear();
	//display pairs
	ROS_INFO("The furthest pairs are %d at %f , %f and %d at %f , %f", turtle1, msg.x, msg.y, turtle2, msg1.x, msg1.y);
	//move the turtle to the two Tturtle pairs

velocity_publisher = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",1000);
//problem
	pose_subscriber = n.subscribe<turtlesim::Pose>("/turtle1/pose",5,poseCallback);
	//moveGoal(msg.x,msg.y,msg1.x,msg1.y);
  return 0;
}
